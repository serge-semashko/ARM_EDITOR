# utlibvlc
Delphi wrapper for VLC1.x/VLC2.x.
Written for my project dboxTV to handle multiple vlc instances.

Developer Forum: http://forum.dschaek.de/board.php?boardid=30

Website: http://www.dschaek.de


